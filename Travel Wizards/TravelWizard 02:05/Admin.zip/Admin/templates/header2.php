<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../Object/css/Header.css"> 

<header class="admin-header">
    <div class="admin-container">
        <div class="admin-logo">TravelWizard</div>
        <div class="admin-title">Employee Dashboard</div>
        <div class="admin-logout">
            <a href="admin_logout.php" class="logout-button">Logout</a>
        </div>
    </div>
</header>
